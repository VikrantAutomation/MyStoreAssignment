package mystore.item.order.tc;



import java.io.IOException;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import org.testng.annotations.Parameters;

import mystore.item.order.po.PO_Mystore_Home;
import mystore.item.order.po.PO_Mystore_Login;
import mystore.item.order.po.PO_Mystore_Order;
import mystore.item.order.po.PO_Mystore_OrderHistory;
import mystore.item.order.util.BrowserManager;
import mystore.item.order.util.CommonUtilities;
import mystore.item.order.util.DriverManager;

public class TC_PurchaceItems extends DriverManager {
	
	ExtentHtmlReporter htmlReporter;
	ExtentReports extent;
	ExtentTest test;
	
	
	
	public TC_PurchaceItems(){
		super();
		
	}
	
	
	@BeforeTest
	public void setUpSuite() {
		
		htmlReporter=new ExtentHtmlReporter("./Reports/extent_UIAutomation.html");	
		extent=new ExtentReports();
		extent.attachReporter(htmlReporter);
	}
	@BeforeMethod
	public void setUpMethod(ITestResult result) {
		
			test=extent.createTest(getClass().getName());	
	}	
	
	@Test
	@Parameters({"browser","url","userName","password"})
	public void t_01_purchace_items(String browser,String url,String userName,String password) {		
      BrowserManager.getDriver(browser,url);            
      PO_Mystore_Login loginPage=new PO_Mystore_Login();
      loginPage.login(userName, password); 
      PO_Mystore_Home home=loginPage.navigateToHomePage();
      home.selectAnyItemAddToCart(0,"M",false);
      home.selectAnyItemAddToCart(1,"Default",true);
      PO_Mystore_Order orderPage= home.navigateToOrderpage();
      orderPage.verifyOrderDetails();
      loginPage= orderPage.CheckoutAndCompleteOrderProcess();
      loginPage.logout();
      }
	
	@Test
	@Parameters({"browser","url","userName","password"})
	public void t_02_SendMessageOnExistingOrders(String browser,String url,String userName,String password) {		
		BrowserManager.getDriver(browser,url);            
	      PO_Mystore_Login loginPage=new PO_Mystore_Login();
	      loginPage.login(userName, password);
	      PO_Mystore_OrderHistory orderHistory=loginPage.navigateToOrderHistoryPage();
	      orderHistory.selectProductAndSendMessage("Good Product",false);
	      }
	
	
	@Test
	@Parameters({"browser","url","userName","password"})
	public void t_03_FailTestForScreenhot(String browser,String url,String userName,String password) {	      
		  BrowserManager.getDriver(browser,url);            
	      PO_Mystore_Login loginPage=new PO_Mystore_Login();
	      loginPage.login(userName, password);
	      PO_Mystore_OrderHistory orderHistory=loginPage.navigateToOrderHistoryPage();
	      orderHistory.selectProductAndSendMessage("Good Product",true);
	      }
	
	@AfterMethod
	public void tearDownMethod(ITestResult result) throws IOException {
		test.log(Status.INFO, result.getName());
		if(ITestResult.FAILURE==result.getStatus()) {
			test.fail("Failed");
			CommonUtilities.takeScreenshotAtEndOfTest(result.getName());
			test.addScreenCaptureFromPath("./screenshots/" +result.getName()+"_extent_"+ System.currentTimeMillis() + ".png");									
		}
		
		driver.quit();
	}
	
	@AfterTest
	public void tearDownSuite() {				
		extent.flush();
		}
}
