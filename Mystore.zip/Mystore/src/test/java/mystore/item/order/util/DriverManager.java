package mystore.item.order.util;

import org.openqa.selenium.WebDriver;

public class DriverManager {
	public static WebDriver driver;	

}
