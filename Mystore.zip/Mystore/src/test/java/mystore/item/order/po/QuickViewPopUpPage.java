package mystore.item.order.po;

public class QuickViewPopUpPage {
	
	public QuickViewPopUpPage() {
		System.out.println("this is constructor");
	}

}
