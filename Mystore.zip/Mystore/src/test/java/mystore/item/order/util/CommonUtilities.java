package mystore.item.order.util;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Reporter;

import com.google.common.io.Files;


public class CommonUtilities extends DriverManager {	
		
	public static void mouseHover(WebElement element) {
		//Creating object of an Actions class
		Actions action = new Actions(driver);

		//Performing the mouse hover action on the target element.
		action.moveToElement(element).perform();
		Reporter.log("Mouse Hover successfull",true);	
	}
	
	public static void takeScreenshotAtEndOfTest(String testCaseName) throws IOException {
		File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		//String currentDir = System.getProperty("user.dir");		
		Files.copy(scrFile, new File("./screenshots/" +testCaseName+"_"+ System.currentTimeMillis() + ".png")); // + means append with current timemillis
		
		}

}
