package mystore.item.order.po;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Reporter;

import mystore.item.order.util.DriverManager;

public class PO_Mystore_QuickViewPopUp extends DriverManager {
	

	@FindBy(id="group_1")
	private WebElement sizeDropdown;
	
	@FindBy(css="p#add_to_cart button")
	private WebElement addToCartButton;	
	
	@FindBy(xpath="//div[@class='primary_block row']//h1")
	private WebElement productName;
	
	@FindBy(css="#our_price_display")
	private WebElement productPrice;	
	
	
	public PO_Mystore_QuickViewPopUp() {	
		
		PageFactory.initElements(driver, this);
		Reporter.log("In Constructor");
	}
	
	//Methods
	
	public String getProductName() {
		Reporter.log("Product Name - "+productName.getText(),true);
		return productName.getText();		 
	}
	
	public String getProductPrice() {
		Reporter.log("Product Price - "+productPrice.getText(),true);
		return productPrice.getText().replaceAll("\\$", "").replaceAll(" ", "");	 
	}	
	
	public void selectSizeDropdown(String itemSize) {
		Select dropdown=new Select(sizeDropdown);
		dropdown.selectByVisibleText(itemSize);	
		Reporter.log("Size selected is "+itemSize,true);
	}	
	
	public void clickAddtoCartButton() {		
		addToCartButton.click();
		Reporter.log("Add to cart button is clicked",true);
	}	
	
	//Business Methods
	public void selectSizeAndAddToCart(String size) {
		
		if(size.equals("S")||size.equals("M")||size.equals("L")) {
			selectSizeDropdown(size);
		}
		
		clickAddtoCartButton();		
	}
	

}

