package mystore.item.order.po;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;

import mystore.item.order.util.DriverManager;

public class PO_Mystore_Login extends DriverManager {
	WebDriverWait wait;

	public PO_Mystore_Login() {
		// this.driver=driver;

		PageFactory.initElements(driver, this);
		wait = new WebDriverWait(driver,30);
	}

	@FindBy(css = "a.login")
	private WebElement signIn_link;

	@FindBy(id = "email")
	private WebElement email_txtBox;

	@FindBy(id = "passwd")
	private WebElement password_txtBox;

	@FindBy(id = "SubmitLogin")
	private WebElement sign_In_btn;

	@FindBy(xpath = "//a[@title='Home']/span")
	private WebElement home_btn;
	
	@FindBy(xpath = "//span[text()='Order history and details']")
	private WebElement orderHistory_btn;

	@FindBy(css = "a.logout")
	private WebElement signout_link;

	// Methods
	public void Click_SignIn_Link() {
		signIn_link.click();
		Reporter.log("Clicked on SignIn Link", true);
	}

	public void Click_Signout_Link() {
		signout_link.click();
		Reporter.log("Clicked on Sign out Link", true);
	}

	public void Click_SignIn_Btn() {
		sign_In_btn.click();
		Reporter.log("Clicked on SignIn button", true);
	}

	public void Click_Home_Btn() {
		home_btn.click();
		Reporter.log("Clicked on Home button", true);
	}

	public void Click_OrderHistory_Btn() {
		orderHistory_btn.click();
		Reporter.log("Clicked on Order History button", true);
	}
	
	public void SetEmailIdTextBox(String email) {
		email_txtBox.sendKeys(email);
		Reporter.log("Entered email Id " + email, true);
	}

	public void SetPasswordTextBox(String pwd) {
		password_txtBox.sendKeys(pwd);
		Reporter.log("Entered Password ********", true);
	}

	// Business Method
	public void login(String emailId, String pwd) {
		Click_SignIn_Link();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Assert.assertEquals(driver.getTitle(), "Login - My Store", "User is not on Login page");
		SetEmailIdTextBox(emailId);
		SetPasswordTextBox(pwd);
		Click_SignIn_Btn();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Assert.assertEquals(driver.getTitle(), "My account - My Store", "User is not on My account page");
		Reporter.log("Logged in successfully", true);	
	}
	
	public PO_Mystore_Home navigateToHomePage() {		
		Click_Home_Btn();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Assert.assertEquals(driver.getTitle(), "My Store", "User is not on Home page");				
		return new PO_Mystore_Home();
	}
	
	public PO_Mystore_OrderHistory navigateToOrderHistoryPage() {				
		Click_OrderHistory_Btn();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Assert.assertEquals(driver.getTitle(), "Order history - My Store", "User is not on Home page");				
		return new PO_Mystore_OrderHistory();
	}
	
	

	public void logout() {
		Click_Signout_Link();
		Assert.assertTrue(signIn_link.isDisplayed(), "Sign In button is not displayed. User is not logged out");
		Reporter.log("User is logged out successfully", true);
	}

}
