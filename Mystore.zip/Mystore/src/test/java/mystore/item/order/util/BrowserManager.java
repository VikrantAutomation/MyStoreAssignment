package mystore.item.order.util;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Reporter;

public class BrowserManager extends DriverManager {
	//public static WebDriver driver;	
	
	public static void getDriver(String browserType,String url) {
		
		if(browserType.equals("Chrome")) {		
			String directory = System.getProperty("user.dir");
			Reporter.log(directory,true);
			String driverExecPath=directory +"\\src\\test\\java\\drivers\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", driverExecPath);
		driver=new ChromeDriver();
		}
	      driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	      driver.manage().window().maximize();
	      driver.get(url);
	      Reporter.log("Navigated to Browser:"+browserType+" URL:"+url,true);
	      //return driver;
	}
	

}
