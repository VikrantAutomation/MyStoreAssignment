package mystore.item.order.tc;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import mystore.item.order.util.CommonUtilities;

public class TC_API_Automation {
	
	ExtentHtmlReporter htmlReporter2;
	ExtentReports extent2;
	ExtentTest test2;
	
	
	@BeforeSuite
	public void setUpSuite() {
		
		htmlReporter2=new ExtentHtmlReporter("./Reports/extent_APIAutomation.html");	
		extent2=new ExtentReports();
		extent2.attachReporter(htmlReporter2);
	}
	
	@BeforeMethod
	public void setUpMethod(ITestResult result) {
		
			test2=extent2.createTest(getClass().getName());	
	}
	
	@Test
	public void tc_01_GetUsers() {
		// Base URI
		RestAssured.baseURI="https://reqres.in/api";
		//Request object
		RequestSpecification httpRequest=RestAssured.given();
		//Response object
		Response response=httpRequest.request(Method.GET,"/users?page=2");		
		// Status code verification 
		Assert.assertEquals(response.getStatusCode(), 200);
		//Status line verification
		Assert.assertEquals(response.getStatusLine(), "HTTP/1.1 200 OK");		
	}
	
	@Test
	public void tc_02_POST_CreateUser() {
	RestAssured.baseURI="https://reqres.in/api";
	RequestSpecification httpRequest=RestAssured.given();	
	//Request payload sending along with post request
	JSONObject requestParams=new JSONObject();
	requestParams.put("name", "Abc");
	requestParams.put("job", "Manager");
	httpRequest.header("Content-Type","application/json");
	//attach data to request
	httpRequest.body(requestParams.toJSONString()); 
	//Response Object
	Response response=httpRequest.request(Method.POST,"/users");
	JsonPath jsonpath=response.jsonPath();	
	//Status code verification
	Assert.assertEquals(response.getStatusCode(), 201);
	Assert.assertEquals(jsonpath.get("name"),"Abc");
	Assert.assertEquals(jsonpath.get("job"),"Manager");
	System.out.println(response.getBody().asString());
	}
	
	@Test
	public void tc_03_UPDATE_UpdateUser() {
		RestAssured.baseURI="https://reqres.in/api";
		RequestSpecification httpRequest=RestAssured.given();	
		//Request payload sending along with post request
		JSONObject requestParams=new JSONObject();
		requestParams.put("name", "Abc");
		requestParams.put("job", "Manager");
		httpRequest.header("Content-Type","application/json");
		//attach data to request
		httpRequest.body(requestParams.toJSONString()); 
		//Response Object
		Response response=httpRequest.request(Method.POST,"/users");
		JsonPath jsonpath=response.jsonPath();	
		//Status code verification
		Assert.assertEquals(response.getStatusCode(), 201);
		Assert.assertEquals(jsonpath.get("name"),"Abc");
		Assert.assertEquals(jsonpath.get("job"),"Manager");
		System.out.println(response.getBody().asString());
		
		// Update user validation
		Response response2=httpRequest.request(Method.PUT,"/users/"+jsonpath.get("id"));
		JsonPath jsonpath2=response2.jsonPath();	
		//Validation		
		Assert.assertEquals(jsonpath2.get("name"),"Abc");
		Assert.assertEquals(jsonpath2.get("job"),"Manager");
		System.out.println(response2.getBody().asString());
		
	}
	
	@Test
	public void tc_04_DELETE_DeleteUser() {
		RestAssured.baseURI="https://reqres.in/api";
		RequestSpecification httpRequest=RestAssured.given();	
		//Request payload sending along with post request
		JSONObject requestParams=new JSONObject();
		requestParams.put("name", "Abc");
		requestParams.put("job", "Manager");
		httpRequest.header("Content-Type","application/json");
		//attach data to request
		httpRequest.body(requestParams.toJSONString()); 
		//Response Object
		Response response=httpRequest.request(Method.POST,"/users");
		JsonPath jsonpath=response.jsonPath();	
		//Status code verification
		Assert.assertEquals(response.getStatusCode(), 201);
		Assert.assertEquals(jsonpath.get("name"),"Abc");
		Assert.assertEquals(jsonpath.get("job"),"Manager");
		System.out.println(response.getBody().asString());
		
		// Delete user validation
		Response response2=httpRequest.request(Method.DELETE,"/users/"+jsonpath.get("id"));
		JsonPath jsonpath2=response2.jsonPath();	
		//Status code verification
		Assert.assertEquals(response.getStatusCode(), 201);
		
	}
	
	@AfterMethod
	public void tearDownMethod(ITestResult result) throws IOException {
		test2.log(Status.INFO, result.getName());
		if(ITestResult.FAILURE==result.getStatus()) {
			test2.fail("Failed");								
		}
		
	}
	
	@AfterSuite
	public void tearDownSuite() {				
		extent2.flush();
		}

}
