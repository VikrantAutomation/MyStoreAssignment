package mystore.item.order.po;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;

import mystore.item.order.util.CommonUtilities;
import mystore.item.order.util.DriverManager;

public class PO_Mystore_Home extends DriverManager {
	
	private List<String> cart_productNameList;
	private List<String> cart_productPriceList;
	private List<String> cart_productSizeList;
	WebDriverWait wait;
	
	@FindBys({@FindBy(css = "div#center_column ul#homefeatured a.quick-view span")})
	private List<WebElement> quickViewLinks;
	
	@FindBys({@FindBy(css = "div#center_column ul#homefeatured img")})
	private List<WebElement> imageList;	
	
	@FindBy(css=".fancybox-iframe")
	private WebElement quickViewFrame;
	
	@FindBy(css="div.layer_cart_product h2")
	private WebElement addToCartSuccessMessge;
	
	
	@FindBy(css="div.button-container a[title='Proceed to checkout']")
	private WebElement proceedToCheckoutButton;
	
	@FindBy(css="div.button-container span[title='Continue shopping']")
	private WebElement continueShoppingButton;	
	
	
	public PO_Mystore_Home() {		
		PageFactory.initElements(driver, this);
		cart_productNameList=new ArrayList<String>();
		cart_productPriceList=new ArrayList<String>();
		cart_productSizeList=new ArrayList<String>();
		wait = new WebDriverWait(driver,30);
	}
	
	//Methods
	public void clickContinueShoppingButton() {		
		continueShoppingButton.click();		
		Reporter.log("Continue shopping button is clicked",true);
	}
	
	public void clickProceedToCheckoutButton() {		
		proceedToCheckoutButton.click();
		Reporter.log("Proceed to checkout button is clicked",true);
	}
	
	public String getAddToCartSuccessMessage() {
		Reporter.log("Success Message - "+addToCartSuccessMessge.getText(),true);
		return addToCartSuccessMessge.getText();		 
	}
	
	//Business Methods
	public void selectAnyItemAddToCart(int index,String sizeOfItem,boolean proceedToCheckOut) {		
		JavascriptExecutor js = (JavascriptExecutor) driver;  
        // This  will scroll down the page by  1000 pixel vertical		
        js.executeScript("window.scrollBy(0,1000)");		
		Reporter.log("Size of Items "+quickViewLinks.size(),true);
		CommonUtilities.mouseHover(imageList.get(index));
		//driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);		
		wait.until(ExpectedConditions.elementToBeClickable(quickViewLinks.get(index)));
		quickViewLinks.get(index).click();	
		Reporter.log("Selected the item at position "+index,true);
		//driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);	
		wait.until(ExpectedConditions.visibilityOf(quickViewFrame));
		driver.switchTo().frame(quickViewFrame);
		Reporter.log("Switched to the Quick view pop up ",true);
		PO_Mystore_QuickViewPopUp quickViewPopUp=new PO_Mystore_QuickViewPopUp();
		QuickViewPopUpPage aa=new QuickViewPopUpPage();
		cart_productNameList.add(quickViewPopUp.getProductName());
		cart_productPriceList.add(quickViewPopUp.getProductPrice());
		if(sizeOfItem.equals("S")||sizeOfItem.equals("M")||sizeOfItem.equals("L")) {
		cart_productSizeList.add(sizeOfItem);
		}else {
			cart_productSizeList.add("S");	
		}
		quickViewPopUp.selectSizeAndAddToCart(sizeOfItem);
		driver.switchTo().defaultContent();	
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		if(!proceedToCheckOut) {
			clickContinueShoppingButton();
		}else {
			clickProceedToCheckoutButton();
		}
	}	
	
	public PO_Mystore_Order navigateToOrderpage() {
		Assert.assertEquals(driver.getTitle(), "Order - My Store");
		return new PO_Mystore_Order(cart_productNameList,cart_productPriceList,cart_productSizeList);
	}
	
	
}
