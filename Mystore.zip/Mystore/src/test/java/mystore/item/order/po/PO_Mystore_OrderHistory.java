package mystore.item.order.po;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.Reporter;

import mystore.item.order.util.DriverManager;

public class PO_Mystore_OrderHistory extends DriverManager {
	
	@FindBys({@FindBy(css = "table#order-list td.history_link")})
	private List<WebElement> historyLinks;
	
	@FindBys({@FindBy(css = "table#order-list td.history_link + td")})
	private List<WebElement> dateList;
	
	
	@FindBy(css = "select[name='id_product']")
	private WebElement product_dropdown;
	
	@FindBy(css = "textarea.form-control")
	private WebElement textArea_txtbox;
	
	@FindBy(css = "button[name='submitMessage']")
	private WebElement send_button;
	
	@FindBy(css = "p.alert-success")
	private WebElement alertSuccessMessage;
	
	@FindBy(xpath = "//*[text()='Messages']/following-sibling::div//tbody/tr[1]/td[2]")
	private WebElement message_Logged;
	
	
	
	
	
	
	public PO_Mystore_OrderHistory() {		
		PageFactory.initElements(driver, this);
	}
	
	//Methods
	
		public String getMessageLogged(){
			Reporter.log("Message logged is -"+message_Logged.getText(),true);
			return message_Logged.getText();			
		}
		
		public String getAlertSucecssMessage(){
			Reporter.log("Alert message displayed is -"+alertSuccessMessage.getText().trim(),true);
			return alertSuccessMessage.getText().trim();			
		}
	
		
		public void clickSendButton(){
			send_button.click();
			Reporter.log("Clicked send button",true);
		}
		
		public void selectProductDropdown(int itemIndex) {
			Select dropdown=new Select(product_dropdown);
			dropdown.selectByIndex(itemIndex);
			Reporter.log("Item selected is with index "+itemIndex,true);
		}
		
		public void setTextAreText(String message) {
			textArea_txtbox.sendKeys(message);
			Reporter.log("Message entered in text area ",true);
		}

	
	public void selectProductAndSendMessage(String message,boolean failtest) {		
		for(int i=0;i<dateList.size();i++) {
			if(dateList.get(i).getText().trim().equals("06/01/2021")) {
				historyLinks.get(i).click();
				break;
			}
		}
		
		selectProductDropdown(1);
		setTextAreText(message);
		clickSendButton();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Assert.assertEquals(getAlertSucecssMessage(), "Message successfully sent","Message is not matching");
		if(failtest) {
			Assert.assertEquals(getMessageLogged(), "This assertion is to fail test","Message is not matching");
		}
		Assert.assertEquals(getMessageLogged(), message,"Message is not matching");
	}
	

}
