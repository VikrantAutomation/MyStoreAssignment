package mystore.item.order.po;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;

import mystore.item.order.util.DriverManager;

public class PO_Mystore_Order extends DriverManager {
	
	private List<String> productName;
	private List<String> productPrice;
	private List<String> productSize;
	private double sumOfProductPrice=0.0;
	private double shippingPrice=0.0;
	private double tax=0.0;
	WebDriverWait wait;
	
	@FindBys({@FindBy(css = "td.cart_description p.product-name")})
	private List<WebElement> op_productNameList;
	
	@FindBys({@FindBy(css = "td.cart_description small a[href*='size']")})
	private List<WebElement> op_productSizeList;
	
	@FindBys({@FindBy(css = "td.cart_total span.price")})
	private List<WebElement> op_productPriceList;
	
	@FindBy(css="td#total_shipping")
	private WebElement totalShippingPrice;
	
	@FindBy(css="td#total_tax")
	private WebElement totalTax;
	
	@FindBy(css="td#total_product")
	private WebElement totalProductPrice;
	

	@FindBy(css="span#total_price")
	private WebElement totalPrice;
	
	@FindBy(css="a.standard-checkout span")
	private WebElement summaryProccedToCheckoutButton;
	
	@FindBy(css="button[name='processAddress'] span")
	private WebElement addressProccedToCheckoutButton;
	
	@FindBy(css="input#cgv")
	private WebElement termsAgreementCheckbox;
	
	@FindBy(css="button[name='processCarrier'] span")
	private WebElement shippingProccedToCheckoutButton;
	
	@FindBy(css=".cart_navigation button[type='submit']")
	private WebElement confirmOrderButton;
	
	@FindBy(css="a.bankwire")
	private WebElement bankWirePaymentButton;
	
	@FindBy(css="p.cheque-indent strong")
	private WebElement paymentSuccessMessage;	
	
	
	public PO_Mystore_Order(List<String> productName,List<String> productPrice,List<String> productSize) {		
		PageFactory.initElements(driver, this);
		this.productName=productName;
		this.productPrice=productPrice;
		this.productSize=productSize;
		wait = new WebDriverWait(driver,30);
	}
	
	//Methods
	public void clickSummaryProceedToCheckoutButton() {		
		wait.until(ExpectedConditions.elementToBeClickable(summaryProccedToCheckoutButton));
		summaryProccedToCheckoutButton.click();
		Reporter.log("Proceed to checkout in Summary section is clicked",true);
	}
	
public void clickAddressProceedToCheckoutButton() {
	    wait.until(ExpectedConditions.elementToBeClickable(addressProccedToCheckoutButton));
		addressProccedToCheckoutButton.click();
		Reporter.log("Proceed to checkout in Address section is clicked",true);
	}

public void clickBankWireButton() {	
	wait.until(ExpectedConditions.elementToBeClickable(bankWirePaymentButton));
	bankWirePaymentButton.click();
	Reporter.log("Bank Wire Payment Button is clicked",true);
}

public void clickConfirmOrderButton() {	
	wait.until(ExpectedConditions.elementToBeClickable(confirmOrderButton));
	confirmOrderButton.click();
	Reporter.log("Confirm order Button is clicked",true);
}

public void selectTermsAgreementCheckbox() {	
	termsAgreementCheckbox.click();
	Reporter.log("I agree check box is selected",true);
}

public String getPaymantSuccessMessage() {
	
	return paymentSuccessMessage.getText();	
}

public void clickShippingProceedToCheckoutButton() {
	
	shippingProccedToCheckoutButton.click();
	Reporter.log("Proceed to checkout in Shipping section is clicked",true);
}
	
	public double getTotalProductPrice() {
		Reporter.log(totalProductPrice.getText(),true);
		return Double.parseDouble(totalProductPrice.getText().replaceAll("\\$", "").replaceAll(" ", ""));
	}
	
	public double getTotalShippingPrice() {
		Reporter.log("Total Shipping cost - "+totalShippingPrice.getText(),true);
		return Double.parseDouble(totalShippingPrice.getText().replaceAll("\\$", "").replaceAll(" ", ""));
	}
	
	public double getTotalTax() {
		Reporter.log("Total tax -"+totalTax.getText(),true);
		return Double.parseDouble(totalTax.getText().replaceAll("\\$", "").replaceAll(" ", ""));
	}
	
	public double getTotalPrice() {
		Reporter.log("Total Price -"+totalPrice.getText(),true);
		return Double.parseDouble(totalPrice.getText().replaceAll("\\$", "").replaceAll(" ", ""));
	}
	
	// Business Methods
	public void verifyOrderDetails() {
		for(int i=0;i<productName.size();i++) {
			for(int j=0;j<op_productNameList.size();j++) {
				String OrderPageProductName=op_productNameList.get(j).getText();
				String OrderPageProductPrice=op_productPriceList.get(j).getText().replaceAll("\\$", "").replaceAll(" ", "");
				String OrderPageProductSize=op_productSizeList.get(j).getText().substring(op_productSizeList.get(j).getText().length()-1);
				if(productName.get(i).equals(OrderPageProductName)) {
					Assert.assertEquals(OrderPageProductPrice, productPrice.get(i),"Price for product-"+productName.get(i)+" is not matching");
					Assert.assertEquals(OrderPageProductSize, productSize.get(i),"Size for product-"+productName.get(i)+" is not matching");
					Reporter.log("Verification for Product - "+productName.get(i)+" Product Size - "+OrderPageProductSize+" Product Price - "+OrderPageProductPrice,true);
					sumOfProductPrice=sumOfProductPrice + Double.parseDouble(OrderPageProductPrice); 
				}
			}
		}
		double sum=sumOfProductPrice+getTotalShippingPrice()+getTotalTax();
		Assert.assertEquals(getTotalPrice(),Math.round(sum*100.00)/100.00,"Total price is not matching");	
		}
	
	public PO_Mystore_Login CheckoutAndCompleteOrderProcess() {
		clickSummaryProceedToCheckoutButton();
		clickAddressProceedToCheckoutButton();
		selectTermsAgreementCheckbox();
		clickShippingProceedToCheckoutButton();
		clickBankWireButton();
		clickConfirmOrderButton();
		Assert.assertEquals(getPaymantSuccessMessage(), "Your order on My Store is complete.");
		return new PO_Mystore_Login();
	}
	
}
